# VELOXIS Racing Hub - Ultra-Simple Bootstrapper
# (C) 2026 CHROMESHOT Studio

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$apiBase = "https://veloxis.onrender.com"

# --- UI Setup ---
$form = New-Object Windows.Forms.Form
$form.Text = "VELOXIS Setup"
$form.Size = New-Object Drawing.Size(400, 480)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.BackColor = [Drawing.Color]::FromArgb(10, 10, 15)

# Typography
$fontHead = New-Object Drawing.Font("Segoe UI", 16, [Drawing.FontStyle]::Bold)
$fontSub = New-Object Drawing.Font("Segoe UI", 9)
$fontButton = New-Object Drawing.Font("Segoe UI", 11, [Drawing.FontStyle]::Bold)

# Header
$header = New-Object Windows.Forms.Label
$header.Text = "VELOXIS"
$header.ForeColor = [Drawing.Color]::FromArgb(178, 243, 243)
$header.Font = $fontHead
$header.TextAlign = "MiddleCenter"
$header.Size = New-Object Drawing.Size(300, 40)
$header.Location = New-Object Drawing.Point(50, 30)
$form.Controls.Add($header)

$subHeader = New-Object Windows.Forms.Label
$subHeader.Text = "Racing Hub Setup Protocol"
$subHeader.ForeColor = [Drawing.Color]::Gray
$subHeader.Font = $fontSub
$subHeader.TextAlign = "MiddleCenter"
$subHeader.Size = New-Object Drawing.Size(300, 20)
$subHeader.Location = New-Object Drawing.Point(50, 70)
$form.Controls.Add($subHeader)

# Version Dropdown
$comboVersion = New-Object Windows.Forms.ComboBox
$comboVersion.Location = New-Object Drawing.Point(75, 120)
$comboVersion.Size = New-Object Drawing.Size(250, 30)
$comboVersion.BackColor = [Drawing.Color]::FromArgb(20, 20, 30)
$comboVersion.ForeColor = [Drawing.Color]::White
$comboVersion.FlatStyle = "Flat"
$form.Controls.Add($comboVersion)

# Path Input
$txtPath = New-Object Windows.Forms.TextBox
$txtPath.Location = New-Object Drawing.Point(75, 170)
$txtPath.Size = New-Object Drawing.Size(250, 30)
$txtPath.Text = "C:\VELOXIS Racing Hub"
$txtPath.BackColor = [Drawing.Color]::FromArgb(20, 20, 30)
$txtPath.ForeColor = [Drawing.Color]::LightGray
$txtPath.BorderStyle = "FixedSingle"
$form.Controls.Add($txtPath)

# Hidden AC Path
$acPath = ""
$steamPath = (Get-ItemProperty -Path "HKCU:\Software\Valve\Steam" -Name "SteamPath" -ErrorAction SilentlyContinue).SteamPath
if ($steamPath) {
    if (Test-Path "$steamPath/steamapps/common/assettocorsa") { $acPath = "$steamPath/steamapps/common/assettocorsa" }
}

# Progress & Status
$lblStatus = New-Object Windows.Forms.Label
$lblStatus.Text = "Ready to initialize..."
$lblStatus.ForeColor = [Drawing.Color]::DimGray
$lblStatus.TextAlign = "MiddleCenter"
$lblStatus.Size = New-Object Drawing.Size(300, 20)
$lblStatus.Location = New-Object Drawing.Point(50, 220)
$form.Controls.Add($lblStatus)

$progress = New-Object Windows.Forms.ProgressBar
$progress.Location = New-Object Drawing.Point(75, 250)
$progress.Size = New-Object Drawing.Size(250, 10)
$progress.Style = "Continuous"
$progress.Visible = $false
$form.Controls.Add($progress)

# Data Fetch (GitHub)
$vMap = @{}
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $repoUrl = "https://api.github.com/repos/nowyback/VELOXIS-Releases/releases"
    $releases = Invoke-RestMethod -Uri $repoUrl
    foreach ($release in $releases) {
        $setupAsset = $release.assets | Where-Object { $_.name -like "*setup*.exe" -or $_.name -like "*veloxis*.exe" } | Select-Object -First 1
        if ($setupAsset) {
            $displayName = "$($release.tag_name) (Stable)"
            if ($release.prerelease) { $displayName = "$($release.tag_name) (Beta)" }
            $comboVersion.Items.Add($displayName) | Out-Null
            $vMap[$displayName] = $setupAsset.browser_download_url
        }
    }
    if ($comboVersion.Items.Count -gt 0) { $comboVersion.SelectedIndex = 0 }
} catch {
    $comboVersion.Items.Add("Sync Error") | Out-Null
}

# Install Button
$btnInstall = New-Object Windows.Forms.Button
$btnInstall.Text = "INSTALL NOW"
$btnInstall.BackColor = [Drawing.Color]::FromArgb(178, 243, 243)
$btnInstall.ForeColor = [Drawing.Color]::Black
$btnInstall.FlatStyle = "Flat"
$btnInstall.Font = $fontButton
$btnInstall.Location = New-Object Drawing.Point(75, 300)
$btnInstall.Size = New-Object Drawing.Size(250, 60)

$btnInstall.Add_Click({
    if ($comboVersion.SelectedItem -eq "Sync Error") { return }
    
    $btnInstall.Enabled = $false
    $progress.Visible = $true
    $lblStatus.Text = "Downloading..."
    
    $installPath = $txtPath.Text
    if (!(Test-Path $installPath)) { New-Item -Path $installPath -ItemType Directory | Out-Null }
    
    $ext = [System.IO.Path]::GetExtension($dlUrl)
    if (!$ext) { $ext = ".exe" }
    $tempFile = "$installPath\setup$ext"
    $vName = $comboVersion.SelectedItem
    $dlUrl = $vMap[$vName]
    
    try {
        Invoke-WebRequest -Uri $dlUrl -OutFile $tempFile
        
        if ($tempFile.EndsWith(".zip")) {
            $lblStatus.Text = "Extracting..."
            Expand-Archive -Path $tempFile -DestinationPath $installPath -Force
            Remove-Item $tempFile
        } elseif ($tempFile.EndsWith(".exe")) {
            $lblStatus.Text = "Launching Setup..."
            # Programmatically unblock the file to suppress secondary warnings
            Unblock-File -Path $tempFile -ErrorAction SilentlyContinue
            Start-Process -FilePath $tempFile -Wait
            # Optional: Remove-Item $tempFile
        }

        if ($acPath) {
            $luaAppDir = "$acPath\apps\lua\VELOXIS Racing Hub"
            if (!(Test-Path $luaAppDir)) { New-Item -Path $luaAppDir -ItemType Directory | Out-Null }
            
            if (Test-Path "$installPath\veloxis_validity.lua") {
                Copy-Item -Path "$installPath\veloxis_validity.lua" -Destination "$luaAppDir\main.lua" -Force
            }

            $appData = [Environment]::GetFolderPath('ApplicationData')
            $sigPath = "$appData/veloxis-racing-hub/signals/veloxis_validity_state.json".Replace("\", "/")
            $luaSettingsString = "return { signalPath = `"$sigPath`" }"
            Set-Content -Path "$luaAppDir\veloxis_settings.lua" -Value $luaSettingsString
        }

        $lblStatus.Text = "Done!"
        [Windows.Forms.MessageBox]::Show("Installation Successful.", "VELOXIS")
        $form.Close()
    } catch {
        $msg = $_.Exception.Message
        [Windows.Forms.MessageBox]::Show("Error: $msg", "VELOXIS")
        $btnInstall.Enabled = $true
    }
})

$form.Controls.Add($btnInstall)
$form.ShowDialog()
