@echo off
:: VELOXIS Racing Hub Setup - (C) 2026 CHROMESHOT Studio

pushd "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path '.\veloxisnanoinstaller.ps1') { Unblock-File -Path '.\veloxisnanoinstaller.ps1' -ErrorAction SilentlyContinue }"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0veloxisnanoinstaller.ps1"

if %ERRORLEVEL% neq 0 (
    echo.
    echo --------------------------------------------------
    echo ERROR: Failed to launch setup frequency.
    echo Please manually run 'veloxisnanoinstaller.ps1' with PowerShell.
    echo --------------------------------------------------
    pause
)

popd
